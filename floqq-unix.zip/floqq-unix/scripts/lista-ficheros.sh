#!/bin/bash
# Alex 2014-05-11: lista todos los ficheros del directorio

for fichero in *
do
	echo "Encontrado $fichero"
done 

