#!/bin/bash
# Alex 2014-05-11: hola, mundo

echo "Hola, mundo"

